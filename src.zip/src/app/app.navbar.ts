// import { Component } from "@angular/core";
// import { RouterOutlet } from "@angular/router";

// @Component({
//     selector: 'app-toot',
//     standalone: true,
//     imports: [RouterOutlet],
//     templateUrl: './app.component.html',
//     styles: './app.component.css'
    
// })

// export class {
//     navbar = 'test';
// }