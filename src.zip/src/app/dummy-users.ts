export const DUMMY_USERS = [
    {
        id: 'u1',
        name: 'Joe Schmo',
        image: '1.png'
    },
    {
        id: 'u2',
        name: 'Jane Doe',
        image: '2.png'
    },
    {
        id: 'u3',
        name: 'Han Solo',
        image: '3.png'
    },
    {
        id: 'u4',
        name: 'Dirt Nater',
        image: '4.png'
    },
    {
        id: 'u7',
        name: 'R5D4',
        image: '5.png'
    },
    {
        id: 'u78',
        name: 'Princess Buttercup',
        image: '6.png'
    },
    {
        id: 'u41',
        name: 'Charlie Brown',
        image: '7.png'
    }
]