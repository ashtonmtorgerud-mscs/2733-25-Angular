// import { NgModel } from "@angular/forms";
// import { RouterModule, Routes } from "@angular/router";
// import { AppComponent } from "./app.component";
// import { HomeComponent } from "./home/home.component";


// const routes: Routes = [
//     { path: '', component: HomeComponent }, 
//     { path: 'about-us', component: AppComponent }, 
//     { path: 'calculator', component: AppComponent }, 
// ]

// export class AppRoutingModule { }